package com.nec;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.joda.time.DateTime;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.mongodb.DB;
import com.mongodb.MongoClient;

/**
 * Migrate data from sth to ql
 *
 */
public class App {

	private static File configFile = new File("./application.properties");

	private static String mongodbUrl;
	private static Integer mongodbPortNo;
	private static String qlUrl;
	private static Integer qlPort;
	private static String cratedbUrl;
	private static Integer cratedbPort;
	private static String dbPrefix;
	private static String dataModel;
	private static String mongoContainer;
	private static String sthContainer;
	private static String isDocker;

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		try {
			// Read application.properties file
			FileReader reader = new FileReader(configFile);
			Properties props = new Properties();
			props.load(reader);

			// Extract values from application.properties
			mongodbUrl = props.getProperty("mongodbUrl");
			mongodbPortNo = Integer
					.parseInt(props.getProperty("mongodbPortNo"));
			qlUrl = props.getProperty("qlUrl");
			qlPort = Integer.parseInt(props.getProperty("qlPort"));
			cratedbUrl = props.getProperty("cratedbUrl");
			cratedbPort = Integer.parseInt(props.getProperty("cratedbPort"));
			mongoContainer = props.getProperty("mongoContainer");
			sthContainer = props.getProperty("sthContainer");
			isDocker = props.getProperty("isDocker");

			// Check if os is Windows or Linux
			if (System.getProperty("os.name").startsWith("Windows")) {

				// set dbPrefix and dataModel value from application.properties
				dbPrefix = props.getProperty("dbPrefix");
				dataModel = props.getProperty("dataModel");
			} else {

				// Check if STH-Comet is installed using Docker
				if ("yes".equalsIgnoreCase(isDocker)) {

					// Extract environment variable for dbPrefix
					String[] extdbPrefix = {
							"sh",
							"-c",
							"docker exec " + sthContainer
									+ " bash -c 'echo $DB_PREFIX'" };
					Process processPrefix = Runtime.getRuntime().exec(
							extdbPrefix);
					processPrefix.waitFor();

					// Print error occurred in process execution
					if (processPrefix.exitValue() != 0) {
						InputStream errorStream = processPrefix
								.getErrorStream();
						int c = 0;
						while ((c = errorStream.read()) != -1) {
							System.out.print((char) c);
						}
					}

					// Extract dbPrefix from process
					String strdbPrefix = null;
					BufferedReader stdInputdbPrefix = new BufferedReader(
							new InputStreamReader(
									processPrefix.getInputStream()));
					String str = null;
					while ((str = stdInputdbPrefix.readLine()) != null) {
						strdbPrefix = str;
					}

					// check if dbPrefix value is Empty or not
					if (strdbPrefix != null && !strdbPrefix.isEmpty()) {
						dbPrefix = strdbPrefix;
					} else {

						// Command to extract dbPrefix from config.js
						String extractdbPrefix = "docker exec " + sthContainer
								+ " grep -wR prefix: /opt/sth/config.js";
						Process processPrefix2 = Runtime.getRuntime().exec(
								"" + extractdbPrefix);
						processPrefix2.waitFor();

						// Print error occurred in process execution
						if (processPrefix2.exitValue() != 0) {
							InputStream errorStream = processPrefix2
									.getErrorStream();
							int c = 0;
							while ((c = errorStream.read()) != -1) {
								System.out.print((char) c);
							}
						}

						// Extract dbPrefix from process
						String strdataModel1 = null;
						BufferedReader stdInput1 = new BufferedReader(
								new InputStreamReader(
										processPrefix2.getInputStream()));
						String str1 = null;
						while ((str1 = stdInput1.readLine()) != null) {
							strdataModel1 = str1;
						}
						String dataPrefix[] = strdataModel1.split("'");

						// set value of dbPrefix
						dbPrefix = dataPrefix[1];

					}

					// Extract environment variable for DATA_MODEL
					String[] extdataModel = {
							"sh",
							"-c",
							"docker exec " + sthContainer
									+ "  bash -c 'echo $DATA_MODEL'" };
					Process process1 = Runtime.getRuntime().exec(extdataModel);
					process1.waitFor();

					// Print error occurred in process execution
					if (process1.exitValue() != 0) {
						InputStream errorStream = process1.getErrorStream();
						int c = 0;
						while ((c = errorStream.read()) != -1) {
							System.out.print((char) c);
						}
					}

					// Extract dataModel from process
					String strdataModel = null;
					BufferedReader stdInput = new BufferedReader(
							new InputStreamReader(process1.getInputStream()));
					String str2 = null;
					while ((str2 = stdInput.readLine()) != null) {
						strdataModel = str2;
					}

					// check if dbPrefix value is Empty or not
					if (strdataModel != null && !strdataModel.isEmpty()) {
						dataModel = strdataModel;
					} else {

						// Command to extract dataModel from config.js
						String extractDataModel = "docker exec " + sthContainer
								+ " grep -wR dataModel /opt/sth/config.js";
						Process process2 = Runtime.getRuntime().exec(
								"" + extractDataModel);
						process2.waitFor();

						// Print error occurred in process execution
						if (process2.exitValue() != 0) {
							InputStream errorStream = process2.getErrorStream();
							int c = 0;
							while ((c = errorStream.read()) != -1) {
								System.out.print((char) c);
							}
						}

						// Extract dataModel from process
						String strdataModel1 = null;
						BufferedReader stdInput1 = new BufferedReader(
								new InputStreamReader(process2.getInputStream()));
						String str3 = null;
						while ((str3 = stdInput1.readLine()) != null) {
							strdataModel1 = str3;
						}
						String dataModel1[] = strdataModel1.split("'");

						// set value of dataModel
						dataModel = dataModel1[1];
					}
				} else if ("no".equalsIgnoreCase(isDocker)) {

					// Command to extract dbPrefix from config.js
					String extractdbPrefix = "grep -wR prefix: fiware-sth-comet/config.js";
					Process processPrefix2 = Runtime.getRuntime().exec(
							"" + extractdbPrefix);
					processPrefix2.waitFor();

					// Print error occurred in process execution
					if (processPrefix2.exitValue() != 0) {
						InputStream errorStream = processPrefix2
								.getErrorStream();
						int c = 0;
						while ((c = errorStream.read()) != -1) {
							System.out.print((char) c);
						}
					}

					// Extract dbPrefix from process
					String strdataModel1 = null;
					BufferedReader stdInput1 = new BufferedReader(
							new InputStreamReader(
									processPrefix2.getInputStream()));
					String str1 = null;
					while ((str1 = stdInput1.readLine()) != null) {
						strdataModel1 = str1;
					}
					String dataPrefix[] = strdataModel1.split("'");

					// set value of dbPrefix
					dbPrefix = dataPrefix[1];

					// Command to extract dataModel from config.js
					String extractDataModel = "docker exec " + sthContainer
							+ " grep -wR dataModel fiware-sth-comet/config.js";
					Process process2 = Runtime.getRuntime().exec(
							"" + extractDataModel);
					process2.waitFor();

					// Print error occurred in process execution
					if (process2.exitValue() != 0) {
						InputStream errorStream = process2.getErrorStream();
						int c = 0;
						while ((c = errorStream.read()) != -1) {
							System.out.print((char) c);
						}
					}

					// Extract dataModel from process
					String strdataModel2 = null;
					BufferedReader stdInput2 = new BufferedReader(
							new InputStreamReader(process2.getInputStream()));
					String str3 = null;
					while ((str3 = stdInput2.readLine()) != null) {
						strdataModel2 = str3;
					}
					String dataModel1[] = strdataModel2.split("'");

					// set value of dataModel
					dataModel = dataModel1[1];

				}
			}

		} catch (FileNotFoundException ex) {
			// file does not exist
		} catch (IOException ex) {
			// I/O error
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Variable definition for request
		String fiwareService = null;
		String fiwareServicePath = null;
		String entityType = null;
		String entityId = null;
		String attrName = null;
		JSONParser jsonParser = new JSONParser();

		/***************** Connection with Mongodb ****************/

		MongoClient mongoClient = new MongoClient(mongodbUrl, mongodbPortNo);
		List<String> dbs = mongoClient.getDatabaseNames();

		for (int i = 0; i < dbs.size(); i++) {
			String dbName = dbs.get(i);

			String databaseNameArray[] = null;
			if (dbName.startsWith(dbPrefix)) {
				if (dbName.contains("_")) {
					databaseNameArray = dbs.get(i).split("_");
				}
				DB db = mongoClient.getDB(dbName);
				Set<String> collections = db.getCollectionNames();
				for (String collection : collections) {

					// select collection only for raw data, remove aggr
					// collection
					if (!(collection.endsWith("aggr"))) {

						// Name for sth collection file
						String sthCollection = collection.replace(dbPrefix
								+ "/", dbPrefix);

						// Name for ql collection file
						String qlCollection = sthCollection.replaceAll(
								dbPrefix, "ql_");

						// Check if system is Windows or Linux
						if (System.getProperty("os.name").startsWith("Windows")) {

							// command for mongoexport
							String execCommandSTH = "\"C:/Program Files/MongoDB/Server/4.0/bin/mongoexport\" --db "
									+ dbName
									+ " --collection "
									+ collection
									+ " --out " + sthCollection + ".json";

							// command to run conver_json.py
							String execCommandQL = "python convert_json.py -i "
									+ sthCollection + ".json -o "
									+ qlCollection + ".json";

							// Run commands on cmd
							ProcessBuilder processBuilder = new ProcessBuilder(
									"cmd.exe", "/c", "" + execCommandSTH
											+ " && " + execCommandQL);
							try {
								// start execution of command
								processBuilder.start();
							} catch (IOException e) {
								e.printStackTrace();
							}
						} else {

							// Check if STH-Comet is installed using Docker
							if ("yes".equalsIgnoreCase(isDocker)) {

								// command to execute mongoexport in docker
								// container
								String execcommandDocker = "docker exec "
										+ mongoContainer + " ";
								String execCommandSTH = "mongoexport --db "
										+ dbName + " --collection "
										+ collection + " --out "
										+ sthCollection + ".json";

								// command to copy data from docker container
								String execCommandCopy = "docker cp "
										+ mongoContainer + ":./"
										+ sthCollection + ".json .";

								// command to run conver_json.py
								String execCommandQL = "python convert_json.py -i "
										+ sthCollection
										+ ".json -o "
										+ qlCollection + ".json";

								try {

									// Exeucte command mongoexport
									Process process = Runtime.getRuntime()
											.exec("" + execcommandDocker + ""
													+ execCommandSTH);

									process.waitFor();

									// Print error occurred in process execution
									if (process.exitValue() != 0) {
										InputStream errorStream = process
												.getErrorStream();
										int c = 0;
										while ((c = errorStream.read()) != -1) {
											System.out.print((char) c);
										}
									}

									// Execute command to copy file from docker
									Process process1 = Runtime.getRuntime()
											.exec("" + execCommandCopy);

									process1.waitFor();

									// Print error occurred in process execution
									if (process1.exitValue() != 0) {
										InputStream errorStream = process1
												.getErrorStream();
										int c = 0;
										while ((c = errorStream.read()) != -1) {
											System.out.print((char) c);
										}
									}

									// Execute command to convert data
									Process process2 = Runtime.getRuntime()
											.exec("" + execCommandQL);

									process2.waitFor();

									// Print error occurred in process execution
									if (process2.exitValue() != 0) {
										InputStream errorStream = process2
												.getErrorStream();
										int c = 0;
										while ((c = errorStream.read()) != -1) {
											System.out.print((char) c);
										}
									}
								} catch (IOException e) {
									e.printStackTrace();
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							}

							else if ("no".equalsIgnoreCase(isDocker)) {

								// mongoexport command
								String execCommandSTH = "mongoexport --db "
										+ dbName + " --collection "
										+ collection + " --out "
										+ sthCollection + ".json";

								// convert data command
								String execCommandQL = "python convert_json.py -i "
										+ sthCollection
										+ ".json -o "
										+ qlCollection + ".json";
								try {

									// Execute command mongoexport
									Process process = Runtime.getRuntime()
											.exec("" + execCommandSTH);

									process.waitFor();

									// Print error occurred in process execution
									if (process.exitValue() != 0) {
										InputStream errorStream = process
												.getErrorStream();
										int c = 0;
										while ((c = errorStream.read()) != -1) {
											System.out.print((char) c);
										}

										// Execute command to convert data
										Process process1 = Runtime.getRuntime()
												.exec("" + execCommandQL);

										process1.waitFor();

										// Print error occurred in process
										// execution
										if (process1.exitValue() != 0) {
											InputStream errorStream1 = process1
													.getErrorStream();
											int c1 = 0;
											while ((c1 = errorStream1.read()) != -1) {
												System.out.print((char) c1);
											}
										}
									}
								} catch (IOException e) {
									e.printStackTrace();
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							}
						}

						// Read QL collection file
						File file = new File(qlCollection + ".json");
						String fileName = FilenameUtils.getBaseName(file
								.getName());
						String str[] = fileName.split("_");

						// set fiwareService
						fiwareService = databaseNameArray[1];

						if ("collection-per-entity".equalsIgnoreCase(dataModel)) {
							// Set name of new table in Cratedb
							fiwareServicePath = "/" + str[1];
							entityId = str[2];
							entityType = str[3];
						} else if ("collection-per-attribute"
								.equalsIgnoreCase(dataModel)) {
							// Set name of new table in Cratedb
							fiwareServicePath = "/" + str[1];
							entityId = str[2];
							entityType = str[3];
							attrName = str[4];
						} else if ("collection-per-service-path"
								.equalsIgnoreCase(dataModel)) {
							// Set name of new table in Cratedb

							if ("ql_".equalsIgnoreCase(fileName)) {
								fiwareServicePath = "/";
							} else {
								fiwareServicePath = "/" + str[1];
							}

						}

						try {
							// Buffer to read file properly
							Thread.sleep(2000);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}

						/****************** File Reading ****************/

						try (FileReader reader = new FileReader(file)) {

							// Read JSON file
							Object obj = jsonParser.parse(reader);

							JSONArray array = (JSONArray) obj;
							for (int j = 0; j < array.size(); j++) {
								JSONObject jsonObject = (JSONObject) array
										.get(j);

								// Construct Payload for Request I
								JSONObject requestBody = new JSONObject();
								JSONObject dataObject = new JSONObject();
								JSONObject attrData = new JSONObject();
								JSONObject timeData = new JSONObject();
								JSONArray dataArray = new JSONArray();

								// timeData
								timeData.put("metadata", new JSONObject());
								timeData.put("type",
										DateTime.class.getSimpleName());
								timeData.put("value",
										jsonObject.get("recvTime"));

								// attrData
								attrData.put("metadata", new JSONObject());
								if ("float"
										.equalsIgnoreCase((String) jsonObject
												.get("attrType"))) {
									jsonObject.put("attrType", "Number");
								} else if ("String"
										.equalsIgnoreCase((String) jsonObject
												.get("attrType"))) {
									jsonObject.put("attrType", "Text");
								} else if ("long"
										.equalsIgnoreCase((String) jsonObject
												.get("attrType"))) {
									jsonObject.put("attrType", "Integer");
								}
								attrData.put("type", jsonObject.get("attrType"));
								attrData.put("value",
										jsonObject.get("attrValue"));

								if ("collection-per-entity"
										.equalsIgnoreCase(dataModel)) {
									// dataObject
									dataObject.put("id", entityId);
									dataObject.put(jsonObject.get("attrName"),
											attrData);
									dataObject.put("type", entityType);
								} else if ("collection-per-attribute"
										.equalsIgnoreCase(dataModel)) {
									dataObject.put("id", entityId);
									dataObject.put(attrName, attrData);
									dataObject.put("type", entityType);
								} else if ("collection-per-service-path"
										.equalsIgnoreCase(dataModel)) {
									dataObject.put("id",
											jsonObject.get("entityId"));
									dataObject.put(jsonObject.get("attrName"),
											attrData);
									dataObject.put("type",
											jsonObject.get("entityType"));
									entityType = (String) jsonObject
											.get("entityType");
									entityId = (String) jsonObject
											.get("entityId");

								}

								Double recTime = (Double) jsonObject
										.get("recvTime");

								for (int k = j + 1; k < array.size(); k++) {

									JSONObject jsonObjectnext = (JSONObject) array
											.get(k);
									Double recTimeNext = (Double) jsonObjectnext
											.get("recvTime");

									// compare recTime with recTimeNext value
									int check = recTime.compareTo(recTimeNext);

									if (check == 0) {
										JSONObject attrDataNext = new JSONObject();
										// attrData
										attrDataNext.put("metadata",
												new JSONObject());
										if ("float"
												.equalsIgnoreCase((String) jsonObjectnext
														.get("attrType"))) {
											jsonObjectnext.put("attrType",
													"Number");
										} else if ("String"
												.equalsIgnoreCase((String) jsonObjectnext
														.get("attrType"))) {
											jsonObjectnext.put("attrType",
													"Text");
										} else if ("long"
												.equalsIgnoreCase((String) jsonObjectnext
														.get("attrType"))) {
											jsonObjectnext.put("attrType",
													"Integer");
										}
										attrDataNext.put("type",
												jsonObjectnext.get("attrType"));
										attrDataNext
												.put("value", jsonObjectnext
														.get("attrValue"));

										if ("collection-per-entity"
												.equalsIgnoreCase(dataModel)) {
											// dataObject
											dataObject.put(jsonObjectnext
													.get("attrName"),
													attrDataNext);
										} else if ("collection-per-attribute"
												.equalsIgnoreCase(dataModel)) {
											dataObject.put(attrName,
													attrDataNext);
										} else if ("collection-per-service-path"
												.equalsIgnoreCase(dataModel)) {
											dataObject.put(jsonObjectnext
													.get("attrName"),
													attrDataNext);
										}
										j = k - 1;
									}

								}

								dataObject.put("recvTime", timeData);

								// dataArry
								dataArray.add(dataObject);

								// requestBody
								requestBody.put("data", dataArray);
								requestBody.put("subscriptionID",
										jsonObject.get("id"));

								// POST Request I to QL API /v2/notify to
								// populate your database
								RestTemplate restTemplate = new RestTemplate();
								HttpHeaders headers = new HttpHeaders();
								headers.add("Content-Type", "application/json");

								if (!"default".equalsIgnoreCase(fiwareService)) {
									headers.add("fiware-service", fiwareService);
									headers.add("fiware-servicePath",
											fiwareServicePath);
								}
								HttpEntity<String> entity = new HttpEntity<String>(
										requestBody.toString(), headers);
								String response = restTemplate.postForObject(
										qlUrl + ":" + qlPort + "/v2/notify",
										entity, String.class);

							}

							// Construct Payload for Request II
							JSONObject payload = new JSONObject();
							String updateQuery;
							if ("default".equalsIgnoreCase(fiwareService)) {
								updateQuery = "UPDATE doc.et" + entityType
										+ " SET time_index = recvtime;";
							} else {
								updateQuery = "UPDATE mt" + fiwareService
										+ ".et" + entityType
										+ " SET time_index = recvtime;";
							}

							payload.put("stmt", updateQuery);

							// POST Request II to CrateDB API /_sql for updating
							// "time_index" column values
							RestTemplate restTemplate1 = new RestTemplate();
							HttpHeaders headers1 = new HttpHeaders();
							headers1.add("Content-Type", "application/json");
							HttpEntity<String> entity1 = new HttpEntity<String>(
									payload.toString(), headers1);
							String response1 = restTemplate1.postForObject(
									cratedbUrl + ":" + cratedbPort + "/_sql",
									entity1, String.class);

						} catch (FileNotFoundException e) {
							e.printStackTrace();

						} catch (IOException e) {
							e.printStackTrace();

						} catch (ParseException e) {
							e.printStackTrace();
						}
					}

				}
			}
		}
	}
}
